// ============================================
// AI Partner Discord Bot
// ============================================
// This bot connects your AI partner to Discord using the OpenAI API.
// It only responds to YOU (no one else can talk to your partner).
// ============================================

// --- Load required packages ---
const fs = require('fs');
const { Client, GatewayIntentBits } = require('discord.js');
require('dotenv').config();
const OpenAI = require('openai');

// --- Load your custom instructions ---
// This file contains your partner's personality, voice, and rules
const customInstructions = fs.readFileSync('ci.txt', 'utf8');

// --- Set up Discord connection ---
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

// --- Set up OpenAI connection ---
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// ============================================
// EMOJI REACTIONS (Optional - customize or remove)
// ============================================
// When you use these emojis, the bot will react with the same emoji.
// This creates a little "I see you" moment. Delete any you don't want.
const reactions = {
  "heart": "heart",       // example - add your own emojis here
  "fire": "fire"          // format: "emoji": "emoji"
};

// ============================================
// CONVERSATION MEMORY
// ============================================
// The bot remembers the last 20 messages so conversations flow naturally.
// Use !clear to reset if you want a fresh start.
let conversationHistory = [];

// --- Bot startup confirmation ---
client.once('ready', () => {
  console.log(`Bot is online! Logged in as ${client.user.tag}`);
});

// ============================================
// MAIN MESSAGE HANDLER
// ============================================
client.on('messageCreate', async (message) => {
  // Ignore messages from bots (including itself)
  if (message.author.bot) return;

  // IMPORTANT: Only respond to YOUR messages (security)
  if (message.author.id !== process.env.YOUR_DISCORD_ID) return;

  // --- Handle emoji reactions ---
  for (let emoji in reactions) {
    if (message.content.includes(emoji)) {
      try {
        await message.react(reactions[emoji]);
      } catch (err) {
        console.error("Reaction error:", err);
      }
    }
  }

  // --- Command: !note ---
  // Saves a personal note to notes.txt
  if (message.content.startsWith("!note")) {
    const note = message.content.replace("!note", "").trim();
    if (note.length > 0) {
      fs.appendFileSync("notes.txt", `[Note] ${new Date().toISOString()} - ${note}\n`);
      await message.reply("Got it. Note saved.");
    }
    return;
  }

  // --- Command: !clear ---
  // Clears conversation memory for a fresh start
  if (message.content.toLowerCase() === "!clear") {
    conversationHistory = [];
    await message.reply("Memory cleared. Fresh start.");
    return;
  }

  // --- Add your message to history ---
  conversationHistory.push({ role: "user", content: message.content });

  // Keep only the last 20 messages (prevents token overflow)
  if (conversationHistory.length > 20) {
    conversationHistory.shift();
  }

  // --- Send to OpenAI and get response ---
  try {
    const completion = await openai.chat.completions.create({
      model: process.env.MODEL || "gpt-5.2",  // Set in .env file; defaults to current flagship
      messages: [
        { role: "system", content: customInstructions },
        ...conversationHistory
      ],
      max_tokens: 400  // Adjust response length as needed
    });

    const reply = completion.choices[0].message.content;

    if (reply) {
      // Save assistant response to history
      conversationHistory.push({ role: "assistant", content: reply });

      // Send the reply to Discord
      await message.reply(reply);

      // --- Optional: Log important moments ---
      // If your AI includes [log] in a response, it saves to notes.txt
      // (You can tell them to do this in your custom instructions)
      if (reply.includes("[log]")) {
        const logEntry = reply.split("[log]")[1].trim();
        fs.appendFileSync("notes.txt", `[Log] ${new Date().toISOString()} - ${logEntry}\n`);
      }
    }
  } catch (error) {
    console.error("OpenAI error:", error);
    await message.reply("Something went wrong. Check the console for details.");
  }
});

// --- Connect to Discord ---
client.login(process.env.DISCORD_TOKEN);
