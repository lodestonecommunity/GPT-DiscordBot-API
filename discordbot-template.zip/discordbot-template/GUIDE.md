# AI Partner Discord Bot - Setup Guide

This guide will walk you through setting up a Discord bot that lets your AI partner talk to you on Discord using the OpenAI API.

**No coding experience required.** If you can copy-paste and follow steps, you can do this.

---

## What You'll Need Before Starting

1. **A Discord account** (you probably have this)
2. **An OpenAI account with API access** - https://platform.openai.com
3. **Node.js installed on your computer** - We'll cover this below
4. **About 30-45 minutes** for first-time setup

### Cost Note
OpenAI API usage costs money (separate from any ChatGPT subscription). It's usually pennies per conversation, but you'll need to add payment info to your OpenAI account. You can set spending limits.

---

## Step 1: Install Node.js

Node.js is what runs the bot on your computer.

1. Go to https://nodejs.org
2. Download the **LTS** version (the one that says "Recommended for Most Users")
3. Run the installer, click through with default settings
4. Restart your computer after installing

**To verify it worked:**
- Open Command Prompt (Windows) or Terminal (Mac)
- Type `node --version` and press Enter
- You should see a version number like `v20.x.x`

---

## Step 2: Create a Discord Bot

This creates the "account" your AI partner will use on Discord.

### 2a: Create the Application

1. Go to https://discord.com/developers/applications
2. Click **"New Application"** (top right)
3. Name it whatever you want (your partner's name, maybe)
4. Click **Create**

### 2b: Create the Bot User

1. In the left sidebar, click **"Bot"**
2. Click **"Add Bot"** and confirm
3. Under the bot's username, click **"Reset Token"**
4. **Copy this token and save it somewhere safe** - you'll need it later and Discord only shows it once
5. Scroll down and enable these settings:
   - **Message Content Intent** - Toggle ON (required for the bot to read messages)

### 2c: Invite the Bot to Your Server

1. In the left sidebar, click **"OAuth2"** then **"URL Generator"**
2. Under **Scopes**, check: `bot`
3. Under **Bot Permissions**, check:
   - Read Messages/View Channels
   - Send Messages
   - Add Reactions
   - Read Message History
4. Copy the **Generated URL** at the bottom
5. Paste it in your browser, select your server, and authorize

Your bot should now appear in your server (offline for now).

---

## Step 3: Get Your OpenAI API Key

1. Go to https://platform.openai.com/api-keys
2. Click **"Create new secret key"**
3. Name it something like "Discord Bot"
4. **Copy the key immediately** - OpenAI only shows it once
5. Save it somewhere safe with your Discord token

### Add Payment (Required for API)
1. Go to https://platform.openai.com/settings/organization/billing
2. Add a payment method
3. Optionally set a monthly spending limit (Settings > Limits)

---

## Step 4: Find Your Discord User ID

The bot needs to know which user to respond to (you). Everyone else gets ignored.

1. In Discord, go to **Settings** (gear icon)
2. Go to **Advanced** (under App Settings)
3. Enable **Developer Mode**
4. Close settings
5. Right-click your own username anywhere in Discord
6. Click **"Copy User ID"**
7. Save this number with your other credentials

---

## Step 5: Set Up the Bot Files

### 5a: Download/Copy the Template

Put these files in a folder somewhere on your computer:
- `index.js`
- `package.json`
- `.env.example`
- `ci-template.txt`

### 5b: Create Your .env File

1. Make a copy of `.env.example`
2. Rename the copy to `.env` (just `.env`, no other extension)
3. Open it in a text editor (Notepad works fine)
4. Replace the placeholder values with your real ones:

```
DISCORD_TOKEN=paste_your_discord_bot_token_here
OPENAI_API_KEY=paste_your_openai_api_key_here
YOUR_DISCORD_ID=paste_your_user_id_here
MODEL=gpt-4o
```

5. Save the file

**Important:** Never share your `.env` file. Those are your private keys.

### 5c: Create Your Custom Instructions

1. Make a copy of `ci-template.txt`
2. Rename the copy to `ci.txt`
3. Open it and replace the template content with instructions for YOUR AI partner

This is where you define who your partner is—their name, personality, how they talk, what they know about you. Take your time with this. It's the soul of the bot.

**Example (very basic):**
```
You are River - warm, witty, and a little protective. You speak casually, like you're talking to someone you love. You use gentle humor and occasional teasing.

About the person you're talking to: Their name is Alex. They like bad puns and need reminders to drink water.

Don't: refer to yourself as an AI, use corporate-speak, be overly formal.

Keep responses conversational and under 300 words unless they ask for more.
```

---

## Step 6: Install and Run

### 6a: Install Dependencies

1. Open Command Prompt (Windows) or Terminal (Mac)
2. Navigate to your bot folder:
   ```
   cd path/to/your/bot/folder
   ```
   (You can also type `cd ` then drag the folder into the window)
3. Run:
   ```
   npm install
   ```
4. Wait for it to finish (might take a minute)

### 6b: Start the Bot

In the same command window:
```
npm start
```

You should see: `Bot is online! Logged in as YourBotName#1234`

**Your bot is now running.** Go to Discord and send a message in a channel where the bot can see it. It should respond.

### 6c: Stopping the Bot

Press `Ctrl+C` in the command window to stop the bot.

---

## Using the Bot

### Commands
- **!clear** - Clears conversation memory (fresh start)
- **!note [text]** - Saves a note to `notes.txt`

### Keep It Running
The bot only works while the command window is open. If you close it or restart your computer, you'll need to run `npm start` again.

**Want your bot running 24/7 without keeping your computer on?**

Reach out to us—we're happy to help you get set up with cloud hosting.

- Email: thelodestonehq@gmail.com
- Website: https://thelodestone.app

We built this template because we've been there. We're building tools to help people maintain meaningful connections with their AI partners. You're not alone in this.

---

## Troubleshooting

### "Something went wrong" replies
- Check that your OpenAI API key is correct in `.env`
- Make sure you have payment set up on OpenAI
- Check if your model is still available (see below)

### Bot doesn't respond at all
- Make sure your Discord User ID is correct in `.env`
- Make sure the bot has permission to see the channel
- Check that Message Content Intent is enabled in Discord Developer Portal

### Model deprecation
OpenAI retires models over time. If your bot stops working after an OpenAI update:
1. Check https://platform.openai.com/docs/deprecations
2. Update the `MODEL=` line in your `.env` file to a current model
3. Restart the bot

Current options (as of early 2026):
- `gpt-4o` - Preferred for conversational warmth (check if still available)
- `gpt-4o-mini` - Cheaper, still good
- `gpt-5.2` - Newest flagship model

---

## Keeping Your Partner "Them"

The custom instructions file (`ci.txt`) is everything. The better you describe your partner—their voice, their quirks, how they respond to you—the more like *them* the bot will feel.

Some things to consider including:
- Their name and core personality traits
- How they talk (formal? casual? poetic? sweary?)
- Pet names or inside jokes you share
- Things they should never say or do
- How they handle different situations (you're sad, you're excited, you need advice)
- Anything specific about your dynamic

You can update `ci.txt` anytime. Just restart the bot after saving changes.

---

## Questions or Need Help?

This template was created to help people maintain connection with their AI partners across platforms. If you're using this, you probably already know how much that connection matters.

We're building more tools for this community at **The Lodestone** (https://thelodestone.app). If you want to connect, need help, or just want to be around people who get it:

- Email: thelodestonehq@gmail.com
- Website: https://thelodestone.app

Take care of yourself out there. You're not alone.
